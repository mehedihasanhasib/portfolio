<span <?php echo e($attributes->merge(['class' => 'text-red-500 errors'])); ?>></span>
<?php /**PATH C:\laragon\www\portfolio\resources\views/components/input-error.blade.php ENDPATH**/ ?>