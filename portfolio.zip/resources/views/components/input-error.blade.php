<span {{ $attributes->merge(['class' => 'text-red-500 errors']) }}></span>
